# ABOHAMD CALCULATOR

حاسبة أندرويد (Android 4.2 / API 17 فما فوق) تعرض واجهة HTML/CSS/JS داخل WebView.

## الهيكل

```
.github/workflows/build.yml                         بناء APK تلقائيًا + فحوصات
app/build.gradle                                    إعدادات الوحدة
app/src/main/AndroidManifest.xml
app/src/main/java/com/abohamd/calculator/MainActivity.java
app/src/main/assets/{index.html,style.css,script.js}   واجهة الحاسبة (المصدر الوحيد)
app/src/main/res/mipmap-*/ic_launcher.png
build.gradle  settings.gradle  gradle.properties
```

## البناء

ارفع المحتويات إلى **جذر** المستودع. يعمل الـ workflow عند كل push، وينتج الملف
`ABOHAMD-CALCULATOR-APK` ضمن Artifacts في تبويب Actions.
يفشل البناء إذا كان أي ملف أساسي ناقصًا، أو إذا لم يكن `MainActivity` داخل `classes.dex` في الـ APK.

/*
 * ABOHAMD Calculator logic.
 * Plain ES5 (no let/const, arrow functions, Array.includes, Number.isFinite)
 * so it also runs in the Android 4.2 WebView.
 */
(function () {
    "use strict";

    var expression = document.getElementById("expression");
    var result = document.getElementById("result");
    var jokeBox = document.getElementById("joke");

    var historyToggle = document.getElementById("historyToggle");
    var historyPanel = document.getElementById("historyPanel");
    var historyList = document.getElementById("historyList");
    var clearHistory = document.getElementById("clearHistory");

    var current = "";
    var finished = false;
    var savedHistory = [];

    var jokes = {
        multiplication: [
            "الضرب عمره ما كان حل 💀",
            "يا ساتر وش هالأرقام 😂",
            "الضرب مو كل شيء بالحياة 😭",
            "خف علينا يا نيوتن 🗿",
            "حتى جدول الضرب استقال 📉"
        ],

        division: [
            "القسمة يبيلها رجال 🗿",
            "مب مرجلة ٢ على ١! 😂",
            "وش هالقسمة يا حبيبي؟ 💀",
            "اقسم بالله حيرتني 🤨"
        ],

        addition: [
            "تبي تجمع العالم كله؟ 🌍",
            "الحساب مو تجميع عشوائي 😂",
            "ما شاء الله عليك محاسب 💰"
        ],

        subtraction: [
            "ليش تنقص من الناس؟ 😭",
            "الحياة أخذ وعطا يا صاحبي 💔",
            "ناقصك هدوء بس 😂"
        ],

        large: [
            "ياخي هذا رقم ولا رقم هاتف؟ 📱",
            "الميزانية انهارت 💸",
            "وين بتصرف كل هالأرقام؟ 💀",
            "الأرقام تطلب النجدة 🚨"
        ],

        repeated: [
            "ياخي فهمنا من أول مرة 😭",
            "تختبرني ولا وش؟ 🤨",
            "نفس العملية للمرة الثالثة؟ 💀",
            "عندك شك فيني؟ 😂"
        ]
    };

    var NUMBER_PATTERN = /^(\d+\.?\d*|\.\d+)$/;

    function randomFrom(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    // محلل العمليات الحسابية
    function evaluateMath(input) {
        var tokens = input.match(/\d+\.?\d*|\.\d+|[()+\-*\/%]/g);

        if (!tokens || tokens.join("") !== input) {
            throw new Error("Invalid expression");
        }

        var position = 0;

        function factor() {
            var token = tokens[position];

            if (token === "-") {
                position++;
                return -factor();
            }

            if (token === "+") {
                position++;
                return factor();
            }

            if (token === "(") {
                position++;
                var value = addSub();

                if (tokens[position] !== ")") {
                    throw new Error("Missing bracket");
                }

                position++;
                return value;
            }

            if (!token || !NUMBER_PATTERN.test(token)) {
                throw new Error("Invalid number");
            }

            position++;
            return Number(token);
        }

        function mulDiv() {
            var value = factor();

            while (["*", "/", "%"].indexOf(tokens[position]) !== -1) {
                var operator = tokens[position++];
                var next = factor();

                if ((operator === "/" || operator === "%") && next === 0) {
                    throw new Error("Division by zero");
                }

                if (operator === "*") value *= next;
                if (operator === "/") value /= next;
                if (operator === "%") value %= next;
            }

            return value;
        }

        function addSub() {
            var value = mulDiv();

            while (tokens[position] === "+" || tokens[position] === "-") {
                var operator = tokens[position++];
                var next = mulDiv();

                value = operator === "+" ? value + next : value - next;
            }

            return value;
        }

        var answer = addSub();

        if (position !== tokens.length || !isFinite(answer)) {
            throw new Error("Invalid result");
        }

        return answer;
    }

    // سجل العمليات
    function renderHistory() {
        historyList.innerHTML = "";

        for (var i = 0; i < savedHistory.length; i++) {
            var div = document.createElement("div");
            div.className = "history-item";
            div.textContent = savedHistory[i].operation + " = " + savedHistory[i].answer;
            historyList.appendChild(div);
        }
    }

    function saveHistory(operation, answer) {
        savedHistory.unshift({
            operation: operation,
            answer: answer
        });

        savedHistory = savedHistory.slice(0, 20);
        renderHistory();
    }

    historyToggle.addEventListener("click", function () {
        if (historyPanel.hasAttribute("hidden")) {
            historyPanel.removeAttribute("hidden");
        } else {
            historyPanel.setAttribute("hidden", "");
        }
    });

    clearHistory.addEventListener("click", function () {
        savedHistory = [];
        renderHistory();
    });

    function countInHistory(operation) {
        var count = 0;

        for (var i = 0; i < savedHistory.length; i++) {
            if (savedHistory[i].operation === operation) count++;
        }

        return count;
    }

    // الحساب والردود
    function calculate() {
        if (!current) return;

        var operation = current;

        try {
            var answer = evaluateMath(operation);

            expression.textContent = operation + " =";

            var matches = operation.match(
                /^(-?\d+(?:\.\d+)?)\s*([+*\/-])\s*(-?\d+(?:\.\d+)?)$/
            );

            var joke = null;

            if (countInHistory(operation) + 1 >= 3) {
                joke = randomFrom(jokes.repeated);
            } else if (matches) {
                var a = Number(matches[1]);
                var operator = matches[2];
                var b = Number(matches[3]);

                if (operator === "/" && a === 2 && b === 1) {
                    joke = "مب مرجلة ٢ على ١! 😂";
                } else if (operator === "*" && a >= 5 && b >= 5) {
                    joke = randomFrom(jokes.multiplication);
                } else if (operator === "/" && Math.abs(a) + Math.abs(b) > 1000) {
                    joke = randomFrom(jokes.division);
                } else if (operator === "+" && Math.abs(answer) >= 100000) {
                    joke = randomFrom(jokes.large);
                } else if (operator === "+") {
                    joke = randomFrom(jokes.addition);
                } else if (operator === "-") {
                    joke = randomFrom(jokes.subtraction);
                }
            }

            if (!joke && Math.abs(answer) >= 1000000000) {
                joke = randomFrom(jokes.large);
            }

            // The real answer is always shown; the joke goes on its own line.
            var finalAnswer = String(Number(answer.toPrecision(12)));

            result.textContent = finalAnswer;
            jokeBox.textContent = joke || "";

            saveHistory(operation, finalAnswer);

            finished = true;

        } catch (error) {
            result.textContent = "وش هالحسبة؟ 🤨";
            jokeBox.textContent = "";
            finished = true;
        }
    }

    // تحديث الشاشة
    function updateDisplay() {
        expression.textContent = current;
        result.textContent = current || "0";
        jokeBox.textContent = "";
    }

    function lastNumberHasDot(text) {
        var parts = text.split(/[+\-*\/%]/);
        return parts[parts.length - 1].indexOf(".") !== -1;
    }

    // الأزرار
    function handleButton(button) {
        var action = button.getAttribute("data-action");
        var value = button.getAttribute("data-value");

        if (action === "clear") {
            current = "";
            finished = false;
            expression.textContent = "";
            result.textContent = "0";
            jokeBox.textContent = "";
            return;
        }

        if (action === "delete") {
            if (finished) {
                current = "";
                finished = false;
            } else {
                current = current.slice(0, -1);
            }

            updateDisplay();
            return;
        }

        if (action === "equal") {
            calculate();
            return;
        }

        if (value !== null) {
            if (finished) {
                current = "";
                finished = false;
                expression.textContent = "";
            }

            if (value === "." && lastNumberHasDot(current)) {
                return;
            }

            current += value;
            updateDisplay();
        }
    }

    var buttons = document.querySelectorAll(".buttons button");

    for (var i = 0; i < buttons.length; i++) {
        (function (button) {
            button.addEventListener("click", function () {
                handleButton(button);
            });
        })(buttons[i]);
    }
})();

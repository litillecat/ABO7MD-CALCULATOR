package com.abohamd.calculator;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

/**
 * Hosts the HTML/CSS/JS calculator (app/src/main/assets) inside a WebView.
 * Uses only the plain framework Activity (no AppCompat) and no lambdas,
 * so it runs on Android 4.2 (API 17) and newer.
 */
public class MainActivity extends Activity {

    private static final String START_URL = "file:///android_asset/index.html";
    private static final String ASSET_PREFIX = "file:///android_asset/";

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            webView = new WebView(this);
            configure(webView);
            setContentView(webView);
            webView.loadUrl(START_URL);
        } catch (Exception e) {
            // e.g. the system WebView package is disabled or missing.
            // Show a message instead of crashing on launch.
            webView = null;
            showError(e);
        }
    }

    private void configure(WebView view) {
        view.setBackgroundColor(Color.WHITE);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);          // needed for file:///android_asset
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setTextZoom(100);

        view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                // Keep navigation inside the bundled calculator only.
                return url == null || !url.startsWith(ASSET_PREFIX);
            }
        });
    }

    private void showError(Exception e) {
        TextView text = new TextView(this);
        text.setText("تعذّر تشغيل مكوّن WebView على هذا الجهاز.\n\n"
                + "فعّل أو حدّث \"Android System WebView\" ثم أعد فتح التطبيق.\n\n"
                + e.getClass().getSimpleName());
        text.setTextSize(18);
        text.setGravity(Gravity.CENTER);
        text.setPadding(40, 40, 40, 40);
        setContentView(text);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
